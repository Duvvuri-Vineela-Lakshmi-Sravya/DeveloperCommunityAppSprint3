import axios from 'axios';

const USERS_API_BASE_URL = "http://localhost:8080/api/v1/users";
//const DEVELOPER_API_BASE_URL = "http://localhost:8080/api/v1/user";

class UserService {

    getAllUsers(){
        return axios.get(USERS_API_BASE_URL);
    }

    createUser(user){
        return axios.post(USERS_API_BASE_URL, user);
    }

    deleteUsers(){
        return axios.delete(USERS_API_BASE_URL);
    }
   
}

export default new UserService()

