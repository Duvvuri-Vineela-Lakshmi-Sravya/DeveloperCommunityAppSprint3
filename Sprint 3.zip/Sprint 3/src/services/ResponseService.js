import axios from 'axios';

const RESPONSES_API_BASE_URL = "http://localhost:8080/api/v1/responses";
const RESPONSE_API_BASE_URL = "http://localhost:8080/api/v1/response";

class ResponseService {

    getResponseByfeedId(feedId){
        return axios.get(RESPONSES_API_BASE_URL + '/' + feedId);
    }

    createResponse(response){
        return axios.post(RESPONSES_API_BASE_URL, response);
    }

    updateResponse(response, id){
        return axios.put(RESPONSES_API_BASE_URL + '/' + response, id);
    }

    deleteResponse(id){
        return axios.delete(RESPONSES_API_BASE_URL + '/' + id);
    }
    getResponseById(id)
    {
        return axios.delete(RESPONSE_API_BASE_URL + '/' + id);
    }
    getAllResponses()
    {
        return axios.get(RESPONSES_API_BASE_URL);
    }
   
}

export default new ResponseService()

