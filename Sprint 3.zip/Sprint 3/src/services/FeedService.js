import axios from 'axios';

const FEEDS_API_BASE_URL = "http://localhost:8080/api/v1/feeds";
const FEED_API_BASE_URL = "http://localhost:8080/api/v1/feed";
const FEE_API_BASE_URL = "http://localhost:8080/api/v1/fee";

class FeedService {

    getAllFeeds(){
        return axios.get(FEEDS_API_BASE_URL);
    }

    createFeed(feed){
        return axios.post(FEEDS_API_BASE_URL, feed);
    }

    getFeedByemailId(emailId){
       return axios.get(FEED_API_BASE_URL + '/' + emailId);
    }

    getFeedById(feedId){
        return axios.get(FEE_API_BASE_URL + '/' + feedId);
     }

    updateFeed(feed, feedId){
        return axios.put(FEEDS_API_BASE_URL + '/' + feedId, feed);
    }

    deleteFeed(feedId){
        return axios.delete(FEEDS_API_BASE_URL + '/' + feedId);
    }
   
}

export default new FeedService()

