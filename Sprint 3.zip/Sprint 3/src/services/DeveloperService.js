import axios from 'axios';

const DEVELOPERS_API_BASE_URL = "http://localhost:8080/api/v1/developers";
//const DEVELOPER_API_BASE_URL = "http://localhost:8080/api/v1/developer";

class DeveloperService {

    getAllDevelopers(){
        return axios.get(DEVELOPERS_API_BASE_URL);
    }

    createDeveloper(developer){
        return axios.post(DEVELOPERS_API_BASE_URL, developer);
    }

    //getDeveloperById(developerId){
      //  return axios.get(DEVELOPERS_API_BASE_URL + '/' + developerId);
    //}

    updateDeveloper(developer, developerId){
        return axios.put(DEVELOPERS_API_BASE_URL + '/' + developerId, developer);
    }

    deleteDeveloper(developerId){
        return axios.delete(DEVELOPERS_API_BASE_URL + '/' + developerId);
    }
    getDeveloperByemailId(emailId){
        return axios.get(DEVELOPERS_API_BASE_URL + '/' + emailId);
    }
}

export default new DeveloperService()
