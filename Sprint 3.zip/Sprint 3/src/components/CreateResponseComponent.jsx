import React, { Component } from 'react'
import getCurrentDate from './getCurrentDate';
import ResponseService from '../services/ResponseService'
class CreateResponseComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: '',
            feedId: this.props.match.params.id,
            answer:'',
            respDate:getCurrentDate(),
            answerError:'' 
        }
        
        this.changeanswerHandler=this.changeanswerHandler.bind(this);
        this.saveOrUpdateResponse = this.saveOrUpdateResponse.bind(this);
    }

    validate = () =>{
        let answerError = "";
        if(this.state.answer.length < 2){
            answerError="please,enter the answer.";
        }
        if(answerError)
        {
            this.setState({answerError});
            return false;
        }
        return true;
    };

    
    componentDidMount(){

        // step 4
            ResponseService.getResponseById(this.state.id).then( (res) =>{
                let response = res.data;
                this.setState({
                    feedId:this.props.match.params.feedId,
                    answer : response.answer,
                    respDate: response.respDate
                });
            });
        }      

    saveOrUpdateResponse = (e) => {
        e.preventDefault();
        let response = {feedId: this.props.match.params.feedId,answer:this.state.answer,respDate:this.state.respDate};
        const isValid=this.validate();
        if(isValid){
            console.log('response => ' + JSON.stringify(response));
            this.setState(this.props);
            ResponseService.createResponse(response).then(res =>{
                this.props.history.push('/Dashboard');
                alert("Response added Successfully");
            });
        }
    }
    
    changeanswerHandler= (event) => {
        this.setState({answer: event.target.value});
    }


    cancel(){
        this.props.history.push('/responses');
    }

    getTitle(){
            return <h3 className="text-center">Add your Response</h3>
        }

    render() {
        return (
            <div>
            <br></br>
                <div className = "container">
                    <div className = "row">
                        <div className = "card col-md-6 offset-md-3 offset-md-3">
                            {
                                this.getTitle()
                            }
                            <div className = "card-body">
                                <form>
                                    <div className = "form-group">
                                        <label> Feed Id: </label>
                                        <input name="feedId" className="form-control" 
                                            value={this.props.match.params.feedId}/>
                                    </div>

                                    <div className = "form-group">
                                        <label> Answer : </label>
                                            <textarea placeholder="Answer" name="answer" className="form-control" 
                                            value={this.state.answer} onChange={this.changeanswerHandler}></textarea>
                                    </div>
                                    {this.state.answerError ? (<div style={{fontSize:12,color:"red"}}>{this.state.answerError}</div>) : null }
                                    <br></br>
                                    
                                    <button className="btn btn-success" onClick={this.saveOrUpdateResponse}>Save</button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
        )
    }
}

export default CreateResponseComponent