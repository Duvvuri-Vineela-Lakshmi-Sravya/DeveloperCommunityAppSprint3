import React, { Component } from 'react'
import FeedService from '../services/FeedService'
import  {Link} from 'react-router-dom'

class ListFeedComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            feeds: []
        }
        this.editFeed = this.editFeed.bind(this);
        this.deleteFeed = this.deleteFeed.bind(this);
    }

    deleteFeed(id){
        FeedService.deleteFeed(id).then( res => {
            this.setState({feeds: this.state.feeds.filter(feed => feed.feedId !== id)});
        });
    }
    viewFeed(id){
        this.props.history.push(`/view-feed/${id}`);
    }
    editFeed(id){
        this.props.history.push(`/add-feed/${id}`);
    }

    componentDidMount(){
        FeedService.getAllFeeds().then((res) => {
            this.setState({ feeds: res.data});
        });
    }
    

    render() {
        return (
            <div>
                <center>
                <div className = "row">
                    <table className = "table table-striped table-bordered">

                            <thead>
                                <tr>
                                    <th>Feed Id</th>
                                    <th>Email Id</th>
                                    <th>Topic</th>
                                    <th>Query</th>
                                    <th> Actions</th>
                                </tr>
                            </thead>

                            <tbody>
                                {
                                    this.state.feeds.map(
                                        feed => 
                                        <tr key = {feed.feedId}>
                                            <td>{feed.feedId}</td>
                                            <td> {feed.emailId}</td>
                                            <td> {feed.topic}</td>
                                            <td> {feed.query}</td>
                                            <td>              
                                                <Link className="nav-link" to={`/addResponse/${feed.feedId}`}>
                                                    Add Response
                                                </Link>

                                                <br></br>
               
                                                <Link className="nav-link" to={`/viewResponse/${feed.feedId}`}>
                                                    View Responses
                                                </Link>

                                            </td>
                                        </tr>
                                    )
                                }
                            </tbody>
                    </table>
                </div>
                </center>
            </div>   
        )
    }
}

export default ListFeedComponent