import React, { Component } from 'react'
import FeedService from '../services/FeedService'

class ViewFeedComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            feeds: {}
        }
    }

    componentDidMount(){
        FeedService.getFeedById(this.state.id).then( res => {
            this.setState({feed: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Developer Details</h3>
                    <div className = "card-body">

                    <div className = "row">
                            <label> Feed Id: </label>
                            <div> { this.state.feed.feedId }</div>
                        </div>
                       
                        <div className = "row">
                            <label> Feed Email ID: </label>
                            <div> { this.state.feed.emailId }</div>
                        </div>
                        <div className = "row">
                            <label> Topic : </label>
                            <div> { this.state.feed.topic}</div>
                        </div>
                        <div className = "row">
                            <label> Query : </label>
                            <div> { this.state.feed.query}</div>
                        </div>
                       
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewFeedComponent