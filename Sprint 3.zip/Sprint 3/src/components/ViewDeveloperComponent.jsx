import React, { Component } from 'react'
import DeveloperService from '../services/DeveloperService'

class ViewDeveloperComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            developer: {}
        }
    }

    componentDidMount(){
        DeveloperService.getDeveloperById(this.state.id).then( res => {
            this.setState({developer: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Developer Details</h3>
                    <div className = "card-body">
                        <div className = "row">
                            <label>Name: </label>
                            <div> { this.state.developer.Name }</div>
                        </div>
                       
                        <div className = "row">
                            <label> Developer Email ID: </label>
                            <div> { this.state.developer.emailId }</div>
                        </div>
                        <div className = "row">
                            <label> Password : </label>
                            <div> { this.state.developer.Password}</div>
                        </div>
                        <div className = "row">
                            <label> Role: </label>
                            <div> { this.state.developer.Role}</div>
                        </div>
                        <div className = "row">
                            <label> SkillLevel : </label>
                            <div> { this.state.developer.SkillLevel}</div>
                        </div>
                       

                    </div>

                </div>
            </div>
        )
    }
}

export default ViewDeveloperComponent