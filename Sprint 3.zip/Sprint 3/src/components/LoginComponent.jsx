import React from 'react'
import DeveloperService from '../services/DeveloperService';
import UserService from '../services/UserService';


class LoginComponent extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            emailId: '',
            password:''
        }

        this.changeemailIdHandler = this.changeemailIdHandler.bind(this);
        this.changepasswordHandler=this.changepasswordHandler.bind(this);    
    }

    
    componentDidMount(){
            DeveloperService.getDeveloperByemailId(this.state.emailId).then( (res) =>{
                let developer = res.data;
                this.setState({
                    emailId: developer.emailId,
                    password : developer.password
                });
            });
    }

    validateDeveloper = (e) => {
        e.preventDefault();
        let user={emailId:this.state.emailId};
        let developer = {emailId: this.state.emailId,password:this.state.password};
        console.log('developer => ' + JSON.stringify(developer));
               
                DeveloperService.getDeveloperByemailId(this.state.emailId).then( (res) =>{
                    let dev = res.data;
                    if(dev.emailId===developer.emailId && dev.password===developer.password){
                        this.props.history.push(`/Dashboard/:${dev.emailId}`);
                             alert("Login Successful");
                             UserService.createUser(user);
                        }
                    else
                    {
                        alert("Login Failed");
                    }
                });
            }
  
    changeemailIdHandler= (event) => {
        this.setState({emailId: event.target.value});
    }
    changepasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }
    cancel(){
        this.props.history.push('/developers');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Register</h3>
        }else{
            return <h3 className="text-center">Login</h3>
        }
    }

    render() {
        return (
            <div>                 
            <br></br>
                <div className = "container">
                    <div className = "row">
                        <div className = "card col-md-6 offset-md-3 offset-md-3">
                            {
                                this.getTitle()
                            }
                            <div className = "card-body">
                            <form>
                                 <div className = "form-group">
                                        <label> Email Id: </label>
                                        <input type="email" placeholder="Email Address" name="emailId" className="form-control" 
                                            value={this.state.emailId} onChange={this.changeemailIdHandler}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> Password : </label>
                                            <input type="password" placeholder="Password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changepasswordHandler}/>
                                        </div>
                                       
                                    <button className="btn btn-success" onClick={this.validateDeveloper}>Login</button>
                                    <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default LoginComponent