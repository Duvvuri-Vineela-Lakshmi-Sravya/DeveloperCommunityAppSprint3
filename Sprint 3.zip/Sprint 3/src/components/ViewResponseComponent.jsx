import React, { Component } from 'react'
import ResponseService from '../services/ResponseService'

class ViewResponseComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            id: this.props.match.params.id,
            response: []
        }
    }

    componentDidMount(){
        ResponseService.getResponseByfeedId(this.props.match.params.feedId).then( res => {
            this.setState({response: res.data});
        })
    }

    render() {
        return (
            <div>
                <br></br>
                <div className = "card col-md-6 offset-md-3">
                    <h3 className = "text-center"> View Response Details</h3>
                    <div className = "card-body">
                        <div className = "row">
                            <label> Response ID: </label>
                            <div> { this.state.response.feedId }</div>
                        </div>
                        <div className = "row">
                            <label> Answer : </label>
                            <div> { this.state.response.answer}</div>
                        </div>
                    </div>

                </div>
            </div>
        )
    }
}

export default ViewResponseComponent