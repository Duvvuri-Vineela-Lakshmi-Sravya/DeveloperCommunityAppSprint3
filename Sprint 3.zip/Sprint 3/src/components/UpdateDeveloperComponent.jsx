import React, { Component } from 'react'
import DeveloperService from '../services/DeveloperService';

class UpdateDeveloperComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            password:'',
            emailId: this.props.match.params.emailId
        }
        this.changepasswordHandler = this.changepasswordHandler.bind(this);
        this.updateDeveloper = this.updateDeveloper.bind(this);
    }

    componentDidMount(){
        DeveloperService.getDeveloperByemailId(this.state.emailId).then( (res) =>{
            let developer = res.data;
            this.setState({
                password: developer.password,
                emailId : this.props.match.params.emailId
            });
        });
    }

    updateDeveloper = (e) => {
        e.preventDefault();
        let developer = {password: this.state.password, emailId: this.props.match.params.emailId};
        console.log('developer => ' + JSON.stringify(developer));
        console.log('id => ' + JSON.stringify(this.state.id));
        DeveloperService.updateDeveloper(developer, this.state.emailId).then( res => {
            this.props.history.push('/developers');
        });
    }
    

    changepasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }

    cancel(){
        this.props.history.push('/developers');
    }

    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                <h3 className="text-center">Update Developer</h3>
                                <div className = "card-body">
                                    <form>

                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input name="emailId" className="form-control" 
                                                value={this.props.match.params.emailId}/>
                                        </div>

                                        <div className = "form-group">
                                            <label> New Password: </label>
                                            <input type="password" placeholder="New Password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changepasswordHandler}/>
                                        </div>

                                        <button className="btn btn-success" onClick={this.updateDeveloper}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                   </div>
            </div>
        )
    }
}

export default UpdateDeveloperComponent

