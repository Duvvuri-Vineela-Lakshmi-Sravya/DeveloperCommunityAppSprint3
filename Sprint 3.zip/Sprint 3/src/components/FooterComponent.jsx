import React, { Component } from 'react'

class FooterComponent extends Component {
    constructor(props) {

        super(props)
        this.state = {    

        }
    }

    render() {
        return (
            <div>
                <center>
                    <footer className = "footer">
                        <h1>About</h1>
                        <span>
                            <h5>
                                Communities are usually built on shared struggles of individuals learning in a particular region, 
                                and the goals of each community differ per the individual's collective needs.Over the years, 
                                these developer communities have grown across the world with different goals and missions but still 
                                with the general aim of providing a platform for developers to learn, interact, share ideas, 
                                support each other and grow.
                                "If you want to go quickly, go alone. If you want to go far, go together." – African
                            </h5>
                        </span>
                    </footer>
                </center>
            </div>
        )
    }
}

export default FooterComponent