import React, { Component } from 'react'
import FeedService from '../services/FeedService';
import getCurrentDate from './getCurrentDate';

class CreateFeedComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            
            feedId: this.props.match.params.feedId,
            emailId: '',
            topic:'',
            query:'',
            feedDate:getCurrentDate(),
            emailIdError:'',
            topicError:'',
            queryError:''
        }
       
        this.changetopicHandler=this.changetopicHandler.bind(this);
        this.changequeryHandler=this.changequeryHandler.bind(this);
        this.saveOrUpdateFeed = this.saveOrUpdateFeed.bind(this);
        this.changeemailIdHandler=this.changeemailIdHandler.bind(this);   
    }

    validate = () =>{
        let topicError = "";
        let emailIdError="";
        let queryError="";
        if(this.state.topic.length < 2){
            topicError="Enter valid topic";
        }
        if(this.state.query.length < 2){
            queryError="Enter valid query";
        }
        if(!this.state.emailId.includes("@"))
        {
            emailIdError="Invalid Email";
        }
        if(emailIdError || topicError || queryError)
        {
            this.setState({emailIdError , topicError, queryError});
            return false;
        }
        return true;
    };
    
    componentDidMount(){

            FeedService.getFeedById(this.state.feedId).then( (res) =>{
                let feed = res.data;
                this.setState({
                    feedId: feed.feedId,
                    emailId: feed.emailId,
                    topic : feed.topic,
                    query:feed.query,
                    feedDate:feed.feedDate
               
                });
            });       
    }
    saveOrUpdateFeed = (e) => {
        e.preventDefault();
        let feed = {feedId: this.state.feedId, emailId: this.state.emailId,topic:this.state.topic,
        query:this.state.query,feedDate:this.state.feedDate};
        const isValid=this.validate();
            if(isValid){
                console.log('feed => ' + JSON.stringify(feed));
                this.setState(this.props);
                FeedService.createFeed(feed).then(res =>{
                    this.props.history.push('/Dashboard');
                    alert("Feed Added Successfully.");
                    });
                }
        }
    

    changequeryHandler= (event) => {
        this.setState({query: event.target.value});
    }
    changetopicHandler= (event) => {
        this.setState({topic: event.target.value});
    }
    changeemailIdHandler= (event) => {
       this.setState({emailId: event.target.value});
    }


    cancel(){
        this.props.history.push('/feeds');
    }

    getTitle(){
            return <h3 className="text-center">Add new Feed</h3>
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                    <div className = "form-group">
                                            <label> Email-Id : </label>
                                            <input type="email" placeholder="Confirm mailId" name="emailId" className="form-control" 
                                                value={this.state.emailId} onChange={this.changeemailIdHandler}/>
                                        </div>
                                        {this.state.emailIdError ? (<div style={{fontSize:12,color:"red"}}>{this.state.emailIdError}</div>) : null }
                                        <br></br>

                                        <div className = "form-group">
                                            <label> Topic : </label>
                                            <input placeholder="Topic" name="topic" className="form-control" 
                                                value={this.state.topic} onChange={this.changetopicHandler}/>
                                        </div>
                                        {this.state.topicError ? (<div style={{fontSize:12,color:"red"}}>{this.state.topicError}</div>) : null }
                                        <br></br>

                                        <div className = "form-group">
                                            <label> Query: </label>
                                            <textarea placeholder="Enter your query" name="query" className="form-control" 
                                                value={this.state.query} onChange={this.changequeryHandler}/>
                                        </div>
                                        {this.state.queryError ? (<div style={{fontSize:12,color:"red"}}>{this.state.queryError}</div>) : null }
                                        <br></br>

                                        <button className="btn btn-success" onClick={this.saveOrUpdateFeed}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                   </div>
            </div>
        )
    }
}

export default CreateFeedComponent