import React from 'react'
import { BrowserRouter as  Route, Link } from "react-router-dom";
import UserService from '../services/UserService';
import CreateFeedComponent from './CreateFeedComponent';
import LoginComponent from './LoginComponent';
import ListFeedComponent from './ListFeedComponent';
import UpdateDeveloperComponent from './UpdateDeveloperComponent';



//class Component to dsiplay the Dashboard
class Dashboard extends React.Component {
    constructor(props) {
        super(props)
            //Dashboard is associated with a particular user based on his unique emailId.       
            this.state = {
                emailId:this.props.match.params.emailId
            }  

        //Bind method to check if the user has logged out.
        this.deleteUsers = this.deleteUsers.bind(this);
    }
         
    deleteUsers()
    {
        UserService.deleteUsers().then( res => {
            alert("User Logged out!");
        });  
    }


    render() {
        // for placing different components in the web page.
        return (
            <div>
                
                {/* A Button which has the link so as to direct to that particual component - Add Feed */}
                <Link className="nav-link" to={"/addFeed"}>
                    <center>
                        <button className="btn btn-primary" >Add Feed</button>
                    </center>
                </Link>

                {/* A Button which has the link so as to direct to that particual component - My Profile*/}
                <Link className="nav-link" to={`/myProfile/${this.state.emailId}`}>
                    <center>
                        <button className="btn btn-primary">My Profile</button>
                    </center>
                </Link>
                   
                {/* A Button which has the link so as to direct to that particual component - LOGOUT */}   
                <Link className="nav-link" to={"/login"}>
                    <center>
                        <button className="btn btn-primary" onClick={this.deleteUsers}>LOGOUT</button>
                    </center>
                </Link>       

                {/*To Display the feedsComponent into Dashboard Component */}
                <ListFeedComponent/>                  
  
            </div>

        )
    }
}

export default Dashboard