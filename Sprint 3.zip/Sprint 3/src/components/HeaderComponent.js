import React, { Component } from 'react'

class HeaderComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
                 
        }
    }

    render() {
        return (
            <div>
                <header>
                    <nav className="justify-content-center ">
                        <center>
                            <div className="navbar-brand">
                                <h1>Developer Community App</h1>
                            </div>
                        </center>
                    </nav>
                    <br></br>
                </header>
            </div>
        )
    }
}

export default HeaderComponent