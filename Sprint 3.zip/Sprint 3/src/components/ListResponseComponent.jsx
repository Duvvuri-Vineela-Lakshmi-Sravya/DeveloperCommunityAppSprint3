import React, { Component } from 'react'
import ResponseService from '../services/ResponseService'
import Dashboard from './Dashboard';
import { Route, Link } from "react-router-dom";
class ListResponseComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            responses: [],
            feed:this.props.match.params.feedId
        }
    }


    componentDidMount(){
        ResponseService.getResponseByfeedId(this.state.feed).then((res) => {
            this.setState({ responses: res.data});
        });
    }
   
    

    render() {
        return (
            <div>
                 <center>
                 <div className = "row">
                    <table className = "table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Feed Id</th>
                                <th>Answer</th>
                                <th>Response Date</th>
                            </tr>
                        </thead>

                        <tbody>
                                {
                                    this.state.responses.map(
                                        response => 
                                        <tr key = {response.id}>
                                            <td>{response.id}</td>
                                            <td> {response.feedId}</td>
                                            <td> {response.answer}</td>
                                            <td>{response.respDate}</td>
                                        </tr>
                                    )
                                }
                        </tbody>
                    </table>
                </div>
                </center>


                <Route path="/Dashboard" component={Dashboard} />
                <Link className="nav-link" to={"/Dashboard"}>
                    <center>
                        <button className="btn btn-primary">Back</button>
                    </center>
                </Link>
                 
            </div>
            
        )
    }
}

export default ListResponseComponent