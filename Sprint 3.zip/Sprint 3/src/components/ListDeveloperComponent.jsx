import React, { Component } from 'react'
import DeveloperService from '../services/DeveloperService'
import logos from './logos.png';
import { BrowserRouter as  Route, Link } from "react-router-dom";
import LoginComponent from './LoginComponent';

class ListDeveloperComponent extends Component {
    constructor(props) {
        super(props)
        this.state = {
            //Initially, the list of developers will be empty
            developers: []
        }
        this.addDeveloper = this.addDeveloper.bind(this);
        this.editDeveloper = this.editDeveloper.bind(this);
    }

    editDeveloper(id){
        this.props.history.push(`/add-developer/${id}`);
    }

    addDeveloper(){
        this.props.history.push('/add-developer/_add');
    }

    componentDidMount(){
        DeveloperService.getAllDevelopers().then((res) => {
            this.setState({ developers: res.data});
        });
    }

    render() {
        return (
            <div>
                <center> 
                    <img src={logos} alt="Logo" />
                    <br></br>
                    <div>
                        <br></br>
                        <button className="btn btn-primary" onClick={this.addDeveloper}> Register</button>
                   
                        <Route path="/login" component={LoginComponent} />
                        <Link className="nav-link" to={"/login"}>
                            <button className="btn btn-primary">Login</button>
                        </Link>
                    </div>
                    <br/><br/>        
                 </center>
            </div>
            
        )
    }
}

export default ListDeveloperComponent