import React, { Component } from 'react'
import DeveloperService from '../services/DeveloperService';
import getCurrentDate from './getCurrentDate';
import UserService from '../services/UserService';

class CreateDeveloperComponent extends Component {
    constructor(props) {
        super(props)

        this.state = {
            // step 2
            id: this.props.match.params.id,
            name: '',
            emailId: '',
            password:'',
            role:'Developer',
            skillLevel:'',
            memberSince:getCurrentDate(),
            nameError: '',
            emailIdError:'',
            passwordError:'',
            developers:[]
        }
        this.changenameHandler = this.changenameHandler.bind(this);
        this.changeemailIdHandler = this.changeemailIdHandler.bind(this);
        this.changepasswordHandler=this.changepasswordHandler.bind(this);
        this.changeroleHandler=this.changeroleHandler.bind(this);
        this.changeskillLevelHandler=this.changeskillLevelHandler.bind(this);
        this.saveOrUpdateDeveloper = this.saveOrUpdateDeveloper.bind(this);
    }
    //To validate the inputs obtained from form element
    validate = () =>{
        let nameError = "";
        let emailIdError="";
        let passwordError="";
        if(this.state.name.length < 3){
            nameError="Invalid name";
        }
        if(!this.state.password){
            passwordError="Password cannot be blank";
        }
        if(!this.state.emailId.includes("@"))
        {
            emailIdError="Invalid Email";
        }
        if(emailIdError || nameError || passwordError)
        {
            this.setState({emailIdError , nameError, passwordError});
            return false;
        }
        return true;
    };

    componentDidMount(){
        if(this.state.id === '_add'){
            return
        }else{
            DeveloperService.getDeveloperByemailId(this.state.emailId).then( (res) =>{
                let developer = res.data;
                this.setState({Name: developer.name,
                    emailId: developer.emailId,
                    password : developer.password,
                    role:developer.role,
                    skillLevel:developer.skillLevel,
                    memberSince:developer.memberSince
               
                });
            });
        }        
    }
    saveOrUpdateDeveloper = (e) => {
        e.preventDefault();
        let user={emailId:this.state.emailId};
        let developer = {name: this.state.name,emailId: this.state.emailId,password:this.state.password,
        role:this.state.role,skillLevel:this.state.skillLevel,memberSince:this.state.memberSince};
        const isValid=this.validate();
        if(isValid){
        console.log('developer => ' + JSON.stringify(developer));
        this.setState(this.props);
            if(this.state.id === '_add'){
                DeveloperService.createDeveloper(developer).then(res =>{
                    this.props.history.push(`/Dashboard/:${developer.emailId}`);
                    alert("Registration Successful");
                    UserService.createUser(user);
                });
            }else{
                DeveloperService.updateDeveloper(developer, this.state.id).then( res => {
                    this.props.history.push('/developers');
                });
            }
        }
    }

    
    
    changenameHandler= (event) => {
        this.setState({name: event.target.value});
    }

    changeemailIdHandler= (event) => {
        this.setState({emailId: event.target.value});
    }
    changepasswordHandler= (event) => {
        this.setState({password: event.target.value});
    }
    changeroleHandler= (event) => {
        this.setState({role: event.target.value});
    }
    changeskillLevelHandler= (event) => {
        this.setState({skillLevel: event.target.value});
    }


    cancel(){
        this.props.history.push('/developers');
    }

    getTitle(){
        if(this.state.id === '_add'){
            return <h3 className="text-center">Register</h3>
        }else{
            return <h3 className="text-center">Update Developer</h3>
        }
    }
    render() {
        return (
            <div>
                <br></br>
                   <div className = "container">
                        <div className = "row">
                            <div className = "card col-md-6 offset-md-3 offset-md-3">
                                {
                                    this.getTitle()
                                }
                                <div className = "card-body">
                                    <form>
                                        <div className = "form-group">
                                            <label> Name: </label>
                                            <input placeholder=" Name" name="name" className="form-control" 
                                                value={this.state.name} onChange={this.changenameHandler}/>
                                        </div>
                                        {this.state.nameError ? (<div style={{fontSize:12,color:"red"}}>{this.state.nameError}</div>) : null}
                                        <br></br>

                                        <div className = "form-group">
                                            <label> Email Id: </label>
                                            <input type="email" placeholder="Email Address" name="emailId" className="form-control" 
                                                value={this.state.emailId} onChange={this.changeemailIdHandler}/>
                                        </div>
                                        {this.state.emailIdError ? (<div style={{fontSize:12,color:"red"}}>{this.state.emailIdError}</div>) : null }
                                        <br></br>

                                        <div className = "form-group">
                                            <label> Password : </label>
                                            <input type="password" placeholder="Password" name="password" className="form-control" 
                                                value={this.state.password} onChange={this.changepasswordHandler}/>
                                        </div>
                                        {this.state.passwordError ? (<div style={{fontSize:12,color:"red"}} >{this.state.passwordError}</div>) : null}
                                        <br></br>

                                        <div className = "form-group">
                                            <label> Role : </label>
                                            <input placeholder="role" name="role" className="form-control" 
                                                value="Developer" onChange={this.changeroleHandler}/>
                                        </div>
                                        <div className="form-group">
                                            <label for = "skillLevel">Skill Level :  &nbsp;&nbsp;&nbsp;</label>
                                                <select name="skillLevel" id="skillLevel" value={this.state.skillLevel} onChange={this.changeskillLevelHandler}>
                                                    <option value="" selected disabled hidden>Choose here</option>
                                                    <option value="Beginner">Beginner</option>
                                                    <option value="Intermediate">Intermediate</option>
                                                    <option value="Advanced">Advanced</option>
                                                 </select>

                                        </div>

                                        <button className="btn btn-success" onClick={this.saveOrUpdateDeveloper}>Save</button>
                                        <button className="btn btn-danger" onClick={this.cancel.bind(this)} style={{marginLeft: "10px"}}>Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                   </div>
            </div>
        )
    }
}

export default CreateDeveloperComponent