import React from 'react';
import './App.css';
import {BrowserRouter as Router, Route, Switch} from 'react-router-dom'
import ListDeveloperComponent from './components/ListDeveloperComponent';
import HeaderComponent from './components/HeaderComponent';
import FooterComponent from './components/FooterComponent';
import CreateDeveloperComponent from './components/CreateDeveloperComponent';
import Dashboard from './components/Dashboard';
import LoginComponent from './components/LoginComponent';
import CreateFeedComponent from './components/CreateFeedComponent';
import ListResponseComponent from './components/ListResponseComponent';
import CreateResponseComponent from './components/CreateResponseComponent';
import UpdateDeveloperComponent from './components/UpdateDeveloperComponent';

function App() {
  return (
    <div>
        <Router>
              <HeaderComponent />
                <div className="container">
                    <Switch> 
                          <Route path = "/" exact component = {ListDeveloperComponent}></Route>
                          <Route path = "/developers" component = {ListDeveloperComponent}></Route>
                          <Route path = "/add-developer/:id" component = {CreateDeveloperComponent}></Route>
                          <Route path="/Dashboard/:emailId" component={Dashboard}></Route>
                          <Route path="/Dashboard" component={Dashboard}></Route>
                          <Route path="/login" component={LoginComponent}></Route>
                          <Route path="/addFeed" component={CreateFeedComponent}></Route>
                          <Route path="/viewResponse/:feedId" component={ListResponseComponent} />
                          <Route path="/addResponse/:feedId" component={CreateResponseComponent} />
                          <Route path="/myProfile/:emailId" component={UpdateDeveloperComponent} />
                           {/* <Route path = "/view-developer/:id" component = {ViewDeveloperComponent}></Route>
                         <Route path = "/update-developer/:id" component = {UpdateDeveloperComponent}></Route> */}
                    </Switch>
                </div>
              <FooterComponent />
        </Router>
    </div>
  );
}

export default App;