package net.javaguides.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Developer;
import net.javaguides.springboot.repository.DeveloperRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class DeveloperController {

	@Autowired
	private DeveloperRepository developerRepository;
	
	// get all developers
	@GetMapping("/developers")
	public List<Developer> getAllDevelopers(){
		return developerRepository.findAll();
	}		
	
	// create developer rest api
	@PostMapping("/developers")
	public Developer createDeveloper(@RequestBody Developer developer) {
		
		return developerRepository.save(developer);
	}
	
	// get developer by id rest api
	/*@GetMapping("/developers/{id}")
	public ResponseEntity<Developer> getDeveloperById(@PathVariable Long id) {
		Developer developer = developerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Developer not exist with id :" + id));
		return ResponseEntity.ok(developer);
	}*/
	
	// update developer rest api
	
	@PutMapping("/developers/{id}")
	public ResponseEntity<Developer> updateDeveloper(@PathVariable Long id, @RequestBody Developer developerDetails){
		Developer developer = developerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Developer not exist with id :" + id));
		
		developer.setName(developerDetails.getName());
		developer.setEmailId(developerDetails.getEmailId());
		developer.setPassword(developerDetails.getPassword());
		developer.setRole(developerDetails.getRole());
		developer.setSkillLevel(developerDetails.getSkillLevel());
		//developer.setFeeds(developerDetails.getFeeds());
		developer.setMemberSince(developerDetails.getMemberSince());
		
		Developer updatedDeveloper = developerRepository.save(developer);
		return ResponseEntity.ok(updatedDeveloper);
	}
	
	// delete developer rest api
	@DeleteMapping("/developers/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteDeveloper(@PathVariable Long id){
		Developer developer = developerRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Developer not exist with id :" + id));
		
		developerRepository.delete(developer);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	@GetMapping("/developers/{emailId}")
	public ResponseEntity<Developer> getDeveloperByemailId(@PathVariable String emailId) {
		List<Developer> developers = developerRepository.findAll();
		for(Developer d:developers) {
			if(d.getEmailId().equals(emailId))
				return ResponseEntity.ok(d);	
		}
		return null;
		
	}
}
