package net.javaguides.springboot.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "responses")
public class Response {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)   //Id is primary key here
	private int id;
	private int feedId;
	private String answer;
	private LocalDate respDate;
	public Response() {
		super();
	}
	public Response(int feedId, String answer, LocalDate respDate) {
		super();
		this.feedId = feedId;
		this.answer = answer;
		this.respDate = LocalDate.now();
	}
	public Response(int id, int feedId, String answer, LocalDate respDate) {
		super();
		this.id = id;
		this.feedId = feedId;
		this.answer = answer;
		this.respDate = LocalDate.now();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getFeedId() {
		return feedId;
	}
	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public LocalDate getRespDate() {
		return respDate;
	}
	public void setRespDate(LocalDate respDate) {
		this.respDate = LocalDate.now();
	}
	@Override
	public String toString() {
		return "Response [id=" + id + ", feedId=" + feedId + ", answer=" + answer + ", respDate=" + respDate + "]";
	}
	
}