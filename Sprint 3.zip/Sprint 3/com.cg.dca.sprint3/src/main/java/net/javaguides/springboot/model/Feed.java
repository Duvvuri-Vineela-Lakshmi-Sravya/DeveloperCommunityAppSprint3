package net.javaguides.springboot.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "feeds")
public class Feed {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)   //Id is primary key here
	private int feedId;
	private String emailId;
	 private String topic;
	private String query;
	private LocalDate feedDate;
	
	public Feed() {
		super();
	}

	public Feed(int feedId, String emailId, String topic, String query, LocalDate feedDate) {
		super();
		this.feedId = feedId;
		this.emailId = emailId;
		this.topic = topic;
		this.query = query;
		this.feedDate = LocalDate.now();
	}

	public Feed(String emailId, String topic, String query, LocalDate feedDate) {
		super();
		this.emailId = emailId;
		this.topic = topic;
		this.query = query;
		this.feedDate = LocalDate.now();
	}

	public int getFeedId() {
		return feedId;
	}

	public void setFeedId(int feedId) {
		this.feedId = feedId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public LocalDate getFeedDate() {
		return feedDate;
	}

	public void setFeedDate(LocalDate feedDate) {
		this.feedDate = LocalDate.now();
	}

	@Override
	public String toString() {
		return "Feed [feedId=" + feedId + ", emailId=" + emailId + ", topic=" + topic + ", query=" + query
				+ ", feedDate=" + feedDate + "]";
	}
	

}
