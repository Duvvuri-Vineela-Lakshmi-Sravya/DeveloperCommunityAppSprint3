package net.javaguides.springboot.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Developer;
import net.javaguides.springboot.model.Response;
import net.javaguides.springboot.repository.ResponseRepository;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class ResponseController {

	@Autowired
	private ResponseRepository responseRepository;
		
	
	// create response rest api
	@PostMapping("/responses")
	public Response createResponse(@RequestBody Response response) {
		
		return responseRepository.save(response);
	}
	
	//get all responses
	@GetMapping("/responses")
	public List<Response> getAllResponses(){
		return responseRepository.findAll();
	}	
	
	//get response by id rest api
	@GetMapping("/response/{id}")
	public ResponseEntity<Response> getResponseById(@PathVariable int id) {
		Response response = responseRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Response not exist with id :" + id));
		return ResponseEntity.ok(response);
	}
	
	// update response rest api
	
	@PutMapping("/responses/{id}")
	public ResponseEntity<Response> updateResponse(@PathVariable int id, @RequestBody Response responseDetails){
		Response response = responseRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Response not exist with id :" + id));
		
		response.setAnswer(responseDetails.getAnswer());
		
		Response updatedResponse = responseRepository.save(response);
		return ResponseEntity.ok(updatedResponse);
	}
	
	// delete response rest api
	@DeleteMapping("/responses/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteResponse(@PathVariable int id){
		Response response = responseRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Response not exist with id :" + id));
		
		responseRepository.delete(response);
		Map<String, Boolean> res = new HashMap<>();
		res.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(res);
	}
	@GetMapping("/responses/{feedId}")
	public List<Response> getResponseByfeedId(@PathVariable int feedId) {
		List<Response> responses = responseRepository.findAll();
		List<Response> response= new ArrayList<Response>();
		for(Response d:responses) {
			if(d.getFeedId()==feedId) {
				response.add(d);
			}
		}
			return response;
		}
		
	}