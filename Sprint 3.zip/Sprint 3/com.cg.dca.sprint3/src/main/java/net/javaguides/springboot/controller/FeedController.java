package net.javaguides.springboot.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import net.javaguides.springboot.exception.ResourceNotFoundException;
import net.javaguides.springboot.model.Developer;
import net.javaguides.springboot.model.Feed;
import net.javaguides.springboot.repository.FeedRepository;


@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class FeedController {

	@Autowired
	private FeedRepository feedRepository;
	
	// get all feeds
	@GetMapping("/feeds")
	public List<Feed> getAllFeeds(){
		return feedRepository.findAll();
	}	
	
	@GetMapping("/feed/{emailId}")
	public ResponseEntity<Feed> getFeedByemailId(@PathVariable String emailId) {
		List<Feed> feeds = feedRepository.findAll();
		for(Feed f:feeds) {
			if(f.getEmailId().equals(emailId))
				return ResponseEntity.ok(f);	
		}
		return null;
		
	}
	
	
	// create feed rest api
	@PostMapping("/feeds")
	public Feed createFeed(@RequestBody Feed feed) {
		
		return feedRepository.save(feed);
	}
	
	// get feed by id rest api
	@GetMapping("/fee/{feedId}")
	public ResponseEntity<Feed> getFeedById(@PathVariable int feedId) {
		Feed feed = feedRepository.findById(feedId)
				.orElseThrow(() -> new ResourceNotFoundException("Feed not exist with id :" + feedId));
		return ResponseEntity.ok(feed);
	}
	
	// update feed rest api
	
	@PutMapping("/feeds/{feedId}")
	public ResponseEntity<Feed> updateFeed(@PathVariable int feedId, @RequestBody Feed feedDetails){
		Feed feed = feedRepository.findById(feedId)
				.orElseThrow(() -> new ResourceNotFoundException("Feed not exist with id :" + feedId));
		
		feed.setQuery(feedDetails.getQuery());
		feed.setTopic(feedDetails.getTopic());
		
		Feed updatedFeed = feedRepository.save(feed);
		return ResponseEntity.ok(updatedFeed);
	}
	
	// delete feed rest api
	@DeleteMapping("/feeds/{feedId}")
	public ResponseEntity<Map<String, Boolean>> deleteFeed(@PathVariable int feedId){
		Feed feed = feedRepository.findById(feedId)
				.orElseThrow(() -> new ResourceNotFoundException("Feed not exist with id :" + feedId));
		
		feedRepository.delete(feed);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	/*@GetMapping("/feeds/{topic}")
	public ResponseEntity<Feed> getFeedByTopic(@PathVariable String topic) {
		List<Feed> feeds = feedRepository.findAll();
		for(Feed d:feeds) {
			if(d.getTopic().equals(topic))
				return ResponseEntity.ok(d);	
		}
		return null; */
		
	
}