package net.javaguides.springboot.model;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "developers")
public class Developer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	private String name;
	@Column(unique=true)
	private String emailId;
	private String password;
	private String role;
	private String skillLevel;
	private LocalDate memberSince;
	
	public Developer() {
		
	}
	
	public Developer(long id, String name, String emailId, String password, String role, String skillLevel,
			LocalDate memberSince) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.password = password;
		this.role = "Developer";
		this.skillLevel = skillLevel;
		this.memberSince = LocalDate.now();
	
	}


	public Developer(String name, String emailId, String password, String role, String skillLevel, LocalDate memberSince
		) {
		super();
		this.name = name;
		this.emailId = emailId;
		this.password = password;
		this.role = "Developer";
		this.skillLevel = skillLevel;
		this.memberSince = LocalDate.now();
	

	}

	public Developer(long id, String name, String emailId, String password, String role, String skillLevel
		) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.password = password;
		this.role = "Developer";
		this.skillLevel = skillLevel;
	
	}


	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}


	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getRole() {
		return role;
	}



	public void setRole(String role) {
		this.role = "Developer";
	}



	public String getSkillLevel() {
		return skillLevel;
	}



	public void setSkillLevel(String skillLevel) {
		this.skillLevel = skillLevel;
	}



	public LocalDate getMemberSince() {
		return memberSince;
	}



	public void setMemberSince(LocalDate memberSince) {
		this.memberSince = LocalDate.now();
	}

	@Override
	public String toString() {
		return "Developer [id=" + id + ", name=" + name + ", emailId=" + emailId + ", password=" + password + ", role="
				+ role + ", skillLevel=" + skillLevel + ", memberSince=" + memberSince + "]";
	}



}
